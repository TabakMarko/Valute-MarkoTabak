package com.example.valutemarkotabak;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private EditText etAmount;
    private Spinner spCurrency;
    private Button btnConvert;
    private TextView tvResult1;
    private TextView tvResult2;
    private TextView tvResult3;

    private static final double USD_RATE1 = 0.16;
    private static final double EUR_RATE1 = 0.15;
    private static final double CHF_RATE1 = 0.10;
    private static final double USD_RATE2 = 0.11;
    private static final double EUR_RATE2 = 0.10;
    private static final double CHF_RATE2 = 0.10;
    private static final double USD_RATE3 = 0.13;
    private static final double EUR_RATE3 = 0.12;
    private static final double CHF_RATE3 = 0.10;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etAmount = findViewById(R.id.etAmount);
        spCurrency = findViewById(R.id.spCurrency);
        btnConvert = findViewById(R.id.btnConvert);
        tvResult1 = findViewById(R.id.tvResult1);
        tvResult2 = findViewById(R.id.tvResult2);
        tvResult3 = findViewById(R.id.tvResult3);

        btnConvert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                convertCurrency();
            }
        });
    }

    private void convertCurrency() {

        double amount = Double.parseDouble(etAmount.getText().toString());
        String currency = spCurrency.getSelectedItem().toString();

        double result1 = 0.0;
        double result2 = 0.0;
        double result3 = 0.0;
        switch (currency) {
            case "Srednji Tečaj":
                result1 = amount * USD_RATE1;
                result2 = amount * EUR_RATE1;
                result3 = amount * CHF_RATE1;
                break;
            case "Kupovni Tečaj":
                result1 = amount * USD_RATE2;
                result2 = amount * EUR_RATE2;
                result3 = amount * CHF_RATE2;
                break;
            case "Prodajni Tečaj":
                result1 = amount * USD_RATE3;
                result2 = amount * EUR_RATE3;
                result3 = amount * CHF_RATE3;
                break;
        }

        tvResult1.setText(String.format("%.2f USD", result1));
        tvResult2.setText(String.format("%.2f EUR", result2));
        tvResult3.setText(String.format("%.2f CHF", result3));
    }
}